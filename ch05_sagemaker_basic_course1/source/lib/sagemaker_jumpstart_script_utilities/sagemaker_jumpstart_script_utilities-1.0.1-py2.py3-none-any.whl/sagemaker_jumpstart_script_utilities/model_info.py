import json
import logging
import os


MODEL_INFO_FILE_NAME = "__models_info__.json"
IS_TRAINED_ON_INPUT_DATA = "is_trained_on_input_data"


logging.basicConfig(level=logging.INFO)


def is_input_model_partially_trained(input_model_untarred_path: str) -> bool:
    """Read the model_info file from file system to check if the input model was already trained.

    If the model_info file does not exists or if it does not contain information about previous training, we assume that
    the model was not previously trained.
    """
    input_model_info_file_path = os.path.join(input_model_untarred_path, MODEL_INFO_FILE_NAME)
    try:
        with open(input_model_info_file_path, "r") as f:
            model_info = json.load(f)
            is_trained_on_input_data = model_info[IS_TRAINED_ON_INPUT_DATA]
            assert type(is_trained_on_input_data) == bool, (
                "model_info file corrupted "
                f"{IS_TRAINED_ON_INPUT_DATA} parameter must be "
                f"either True or False, got {is_trained_on_input_data}."
            )
            return is_trained_on_input_data
    except FileNotFoundError:
        logging.info(f"'{input_model_info_file_path}' file could not be found.")
        return False
    except KeyError:
        logging.info(f"'{IS_TRAINED_ON_INPUT_DATA}' not in model info file. Assuming model was not fine-tuned.")
        return False
    except Exception as e:
        logging.error(
            f"Could not read or parse model_info file, exception: '{e}'. To continue training on previously "
            f"trained model, please create a json file {input_model_info_file_path} with"
            f" {IS_TRAINED_ON_INPUT_DATA} parameter set to True. To start training from scratch,"
            f"please create a json file {input_model_info_file_path} with"
            f" {IS_TRAINED_ON_INPUT_DATA} parameter set to False."
        )
        raise
