import os


CSV_EXTENSION = ".csv"


def find_file_path(path: str) -> str:
    """Return the file path of the CSV file.

    If path is a directory, return the path of the data that is located under the directory.

    Args:
        path (str): either a directory or file.

    Returns:
        full file path.

    Raises:
        ValueError if the path points to a file which is not a CSV
        FileNotFoundError if no CSV file was found in the directory (non-recursive)
        RuntimeError if more than one CSV file was found.
    """

    if os.path.isfile(path):
        if not path.endswith(CSV_EXTENSION):
            raise ValueError(f"specified file at path '{path}' must ends with '{CSV_EXTENSION}'.")
        return os.path.join(path)
    else:
        file_paths = [file_path for file_path in os.listdir(path) if file_path.endswith(CSV_EXTENSION)]
        if len(file_paths) == 0:
            raise FileNotFoundError(f"Could not find any valid file ending in '{CSV_EXTENSION}' under '{path}'.")
        if len(file_paths) > 1:
            raise RuntimeError(
                (
                    f"Found more than 1 file ending in '{CSV_EXTENSION}' under '{path}'. "
                    f"Could not resolve ambiguity on which file to use between: '{', '.join(file_paths)}'. "
                    f"Please update the objects in your S3 buckets to have only one '{CSV_EXTENSION}' "
                    f"file and try again."
                )
            )
        return os.path.join(path, file_paths[0])
